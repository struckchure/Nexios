from .file_router import FileRouterConfig, FileRouterPlugin
from .html import HTMLPlugin, HTMLPluginConfig
from .static_file import StaticFilePlugin, StaticFilePluginConfig
