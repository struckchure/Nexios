__version__ = "2.1.0rc1"

ascii_art = f"""
  _   _                 _
 | \\ | |               (_)
 |  \\| |   ___  __  __  _    ___    ___
 | . ` |  / _ \\ \\ \\/ / | |  / _ \\  / __|
 | |\\  | |  __/  >  <  | | | (_) | \\__ \\
 |_| \\_|  \\___| /_/\\_\\ |_|  \\___/  |___/

    🚀 Welcome to Nexios 🚀
      The sleek ASGI Backend Framework
      Version: {__version__}
"""

print(ascii_art)
